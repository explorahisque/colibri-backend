const express = require('express');
const router = express.Router();

// Define rutas aquí si es necesario
// router.get('/ruta', (req, res) => res.send('Ruta de ejemplo'));

module.exports = router;
